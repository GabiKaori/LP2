﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmExercicio2 : Form
    {
        int numero;
        double H=0;
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void txtNumero_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero.Text, out numero))
            {
                MessageBox.Show("Numero inválido");
                txtNumero.Focus();
            }
            else if (numero <=0) 
            {
                MessageBox.Show("Número deve ser maior que 0");
                txtNumero.Focus();
            }
        }

        private void btnNumeroH_Click(object sender, EventArgs e)
        {
            MessageBox.Show(numero.ToString());
            for(double i = 1; i <= numero; i++) {
                H = H + 1 / i;
            }
            MessageBox.Show("O número H é: " + H.ToString());
        }
    }
}
