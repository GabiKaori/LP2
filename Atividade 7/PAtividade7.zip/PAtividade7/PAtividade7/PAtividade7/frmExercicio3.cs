﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnPalindromo_Click(object sender, EventArgs e)
        {
            string palavra = txtPalindromo.Text.Trim().ToUpper();
            palavra = palavra.Replace(" ", "");
            char[] vetor = palavra.ToCharArray();
            Array.Reverse(vetor);
            string contrario = new string(vetor);

            if (string.Compare(palavra, contrario, true) == 0)
            {
                MessageBox.Show(contrario.ToString()+ " é um Palíndromo");
            }
            else
            {
                MessageBox.Show(contrario.ToString() + " não é um Palíndromo");
            }
        }
    }
}
