﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmExercicio4 : Form
    {
        double salario, producao, grat, salBruto;

        private void txtProducao_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtProducao.Text, out producao))
            {
                MessageBox.Show("Valor para produção inválida");
                txtProducao.Focus();
            }
            else if (producao <= 0)
            {
                MessageBox.Show("Valor da produção deve ser maior que 0");
                txtProducao.Focus();
            }
        }

        private void txtSalario_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtSalario.Text, out salario))
            {
                MessageBox.Show("Salário inválido");
                txtSalario.Focus();
            }
            else if (salario <= 0)
            {
                MessageBox.Show("Salário deve ser maior que 0");
                txtSalario.Focus();
            }
        }

        private void txtGratificacao_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtGratificacao.Text, out grat))
            {
                MessageBox.Show("Gratificação inválida");
                txtGratificacao.Focus();
            }
            else if (grat < 0)
            {
                MessageBox.Show("Gratificação não pode ser negativa");
                txtGratificacao.Focus();
            }
        }

        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int B, C, D;

            if (producao >= 150)
            {
                B = 1;
                C = 1;
                D = 1;
            }
            else if (producao >= 120)
            {
                B = 1;
                C = 1;
                D = 0;
            }
            else if (producao >= 100)
            {
                B = 1;
                C = 0;
                D = 0;
            }
            else
            {
                B = 0;
                C = 0;
                D = 0;
            }

            salBruto = salario + salario * (0.05 * B + 0.1 * C + 0.1 * D) + grat;

            if (salBruto > 7000)
            {
                if (producao >= 150 && grat > 0)
                {
                    MessageBox.Show("O salário bruto é: R$ "+ salBruto.ToString());
                }
                else
                {
                    MessageBox.Show("O salário bruto é R$ 7000,00");
                }
            }

            if (salBruto < 7000)
            {
                MessageBox.Show("O salário bruto é: R$ " + salBruto.ToString());
            }

        }
    }
}
