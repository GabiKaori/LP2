﻿namespace PAtividade7
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPalindromo = new System.Windows.Forms.Button();
            this.lblPalara = new System.Windows.Forms.Label();
            this.txtPalindromo = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnPalindromo
            // 
            this.btnPalindromo.Location = new System.Drawing.Point(166, 137);
            this.btnPalindromo.Name = "btnPalindromo";
            this.btnPalindromo.Size = new System.Drawing.Size(132, 73);
            this.btnPalindromo.TabIndex = 0;
            this.btnPalindromo.Text = "Testar Palíndromo";
            this.btnPalindromo.UseVisualStyleBackColor = true;
            this.btnPalindromo.Click += new System.EventHandler(this.btnPalindromo_Click);
            // 
            // lblPalara
            // 
            this.lblPalara.AutoSize = true;
            this.lblPalara.Location = new System.Drawing.Point(79, 71);
            this.lblPalara.Name = "lblPalara";
            this.lblPalara.Size = new System.Drawing.Size(128, 20);
            this.lblPalara.TabIndex = 1;
            this.lblPalara.Text = "Palavra ou Frase";
            // 
            // txtPalindromo
            // 
            this.txtPalindromo.Location = new System.Drawing.Point(274, 65);
            this.txtPalindromo.MaxLength = 50;
            this.txtPalindromo.Name = "txtPalindromo";
            this.txtPalindromo.Size = new System.Drawing.Size(176, 26);
            this.txtPalindromo.TabIndex = 2;
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtPalindromo);
            this.Controls.Add(this.lblPalara);
            this.Controls.Add(this.btnPalindromo);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPalindromo;
        private System.Windows.Forms.Label lblPalara;
        private System.Windows.Forms.TextBox txtPalindromo;
    }
}