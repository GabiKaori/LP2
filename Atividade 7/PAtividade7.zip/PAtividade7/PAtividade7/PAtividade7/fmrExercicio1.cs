﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class fmrExercicio1 : Form
    {
        public fmrExercicio1()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            string frase = rchtxtFrase.Text.Trim().ToUpper();
            int totalR = 0;
            foreach (char letra in frase)
            {
                if ((Char.ToUpper(letra) == 'R'))
                {
                    totalR += 1;
                }
            }
            MessageBox.Show("Quantidade de letras R: " + totalR.ToString());
        }

        private void btnEspaçoBranco_Click(object sender, EventArgs e)
        {
            string frase = rchtxtFrase.Text.Trim();
            int totalBranco = 0;
            int comp = frase.Length;
            for (int i = 0; i < comp; i++)
            {
                if(Char.IsWhiteSpace(frase[i]))
                {
                    totalBranco += 1;
                }
            }
            MessageBox.Show("Quantidade de espaços em branco: "+ totalBranco.ToString());
        }

        private void btnPares_Click(object sender, EventArgs e)
        {
            string frase = rchtxtFrase.Text.Trim().ToUpper();
            char[] vetor = frase.ToCharArray();
            int comp = frase.Length;
            int totalPar = 0;
            int i = 1;

            while (i < comp)
            {
            if (vetor[i] == vetor[i-1])
                    totalPar += 1;
                i++;
            }
            MessageBox.Show("Quantidade de Pares: " +totalPar.ToString());
        }
    }
}
