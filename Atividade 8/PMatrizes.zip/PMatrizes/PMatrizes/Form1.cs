﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";


            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o número {i + 1}º número", "Entrada de Dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
            }

            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int i in vetor)
            {
                auxiliar += i + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Ótavio", "Marcelo", "Pedro", "Thais" };

            lista.Remove("Ótavio");

            string nomes = string.Join(", ", lista.ToArray());

            MessageBox.Show(nomes);


        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[5, 3];
            double media = 0;
            double soma = 0;
            string auxiliar;

            for (int i = 0; i < notas.GetLength(0); i++)
                for (int j = 0; j < notas.GetLength(1); i++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do {i + 1}º aluno: ", "Entrada de Dados");

                    if (!double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show("Nota inválida");
                        j--;
                    }
                    else if (j < 0 && j > 10)
                    {
                        MessageBox.Show("Nota deve estar entre 0 e 10");
                        j--;
                    }
                    else
                    {
                        soma += notas[i, j];
                    }
                    media = soma / 3;

                    MessageBox.Show($"Aluno {i + 1}: média " + media.ToString("F2"));

                }


        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            Exercicio4 form2 = new Exercicio4();
            form2.Show();
        }


        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            Exercício5 form3 = new Exercício5();
            form3.Show();
        }

        private void btnExercicio3_Click_1(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double media;
            string auxiliar = "";

            for (int i = 0; i < 20; i++) 
            {
                double soma = 0;

                for (int j = 0; j < 3; j++)
                {
                    do
                    {
                        auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do {i + 1}º aluno: ", "Entrada de Dados");

                        if (!double.TryParse(auxiliar, out notas[i, j]))
                        {
                            MessageBox.Show("Nota inválida.");
                        }
                        else if (notas[i, j] < 0 || notas[i, j] > 10) 
                        {
                            MessageBox.Show("Nota deve estar entre 0 e 10.");
                        }
                        else
                        {
                            soma += notas[i, j]; 
                            break; 
                        }
                    } while (true); 
                }

                media = soma / 3; 
                MessageBox.Show($"Aluno {i + 1}: média: " +media.ToString("F2")); 
            }
        }
    }
}
