﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Exercício5 : Form
    {
        public Exercício5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            char[,] alunos = new char[5, 10];
            char[] gabarito = new char[10] { 'A', 'C', 'E', 'B', 'D', 'D', 'C', 'E', 'E', 'A' };
            string auxiliar = "";

            for (int i = 1; i < 5 ; i++) 
                for (int j = 1; j < 10; j++) {

                    auxiliar = Interaction.InputBox($"Digite uma resposta para a questão {j}: ", "Entrada de Dados");
                    char[] respostas = auxiliar.ToCharArray();

                    if (respostas[j] == gabarito[j])
                    {
                        lstBxQuestões.Items.Add($"O aluno: {i}, acertou a quastão: {j}. Era {j}, escolheu: " + auxiliar);
                    }
                    else
                    {
                        lstBxQuestões.Items.Add($"O aluno: {i}, errou a quastão: {j}. Era {j}, escolheu: " + auxiliar);
                    }

            }
        }

    }
}
