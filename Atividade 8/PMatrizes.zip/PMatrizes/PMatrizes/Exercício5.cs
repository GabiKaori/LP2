﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Exercício5 : Form
    {
        public Exercício5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            char[,] alunos = new char[20, 10];
            char[] gabarito = new char[10] { 'A', 'C', 'E', 'B', 'D', 'D', 'C', 'E', 'E', 'A' };

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    string resposta = Interaction.InputBox($"Digite a resposta da questão {j + 1} do aluno {i + 1}: ", "Entrada de Dados");

                    if (!string.IsNullOrEmpty(resposta) && resposta.Length == 1 && "ABCDE".Contains(resposta.ToUpper()))
                    {
                        alunos[i, j] = char.ToUpper(resposta[0]);
                    }
                    else
                    {
                        MessageBox.Show("Resposta inválida!");
                        j--;
                    }
                    if (alunos[i, j] == gabarito[j])
                    {
                        lstBxQuestões.Items.Add($"Aluno {i + 1} acertou a questão {j + 1}. Era: {gabarito[j]}, escolheu: {alunos[i, j]}");
                    }
                    else
                    {
                        lstBxQuestões.Items.Add($"Aluno {i + 1} errou a questão {j + 1}. Era: {gabarito[j]}, escolheu: {alunos[i, j]}");
                    }
                }

            }
        }
    }
}
