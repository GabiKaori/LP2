﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            Double[,] nota = new Double[3, 10];
            Char[] gabarito = new char[10] {'D', 'A', 'C', 'E', 'B', 'D', 'B', 'B', 'A', 'C'};
            string auxiliar = "";

            for (int aluno = 0; aluno < 3; aluno++)
            {
                for (int resp = 0; resp < 10; resp++)
                {
                    auxiliar = Interaction.InputBox($"Digite a resposta do aluno {aluno + 1} na {resp +1}º questão:");
                    if (auxiliar != null && char.ToUpper(auxiliar[resp]) == gabarito[resp])
                    {
                        lbRespostas.Items.Add($"Aluno {aluno +1} acertou! Resposta {auxiliar[resp]}");
                    }
                    else
                    {
                        lbRespostas.Items.Add($"Aluno {aluno + 1} errou :( Resposta {auxiliar[resp]}, era {gabarito[resp]}");
                    }
                }
            }  
        }
    }
}
