﻿INSERT INTO CIDADE VALUES
	('Sorocaba', 'SP'),
	('Ibiúna', 'SP'),
	('Mairinque','SP'),
	('Piedade','SP'),
	('São Roque','SP'),
	('São Paulo','SP'),
	('Paranapiacaba','SP'),
	('Pilar do Sul','SP');